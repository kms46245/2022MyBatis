package ch05.ex04;

import ch05.domain.User;

public interface Map {
	int updateUser(User user);
}
