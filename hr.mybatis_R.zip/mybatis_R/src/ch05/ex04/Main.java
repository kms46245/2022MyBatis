package ch05.ex04;

import ch05.domain.User;
import config.Configuration;

public class Main {
	public static void main(String[] args) {
		Map mapper = Configuration.getMapper(Map.class);
		
		if(mapper.updateUser(new User(1, "lusa", null)) > 0)
				System.out.println("lucider -> lusa�� ���� ����");
		
		if(mapper.updateUser(new User(1, "lucider", null)) > 0)
			System.out.println("lusa -> lucider�� ���� ����");
	}
}
