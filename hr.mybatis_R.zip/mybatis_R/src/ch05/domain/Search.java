package ch05.domain;

public class Search {
	private String userName;
	private Post post;
	
	public Search(String userName, Post post) {
		this.userName = userName;
		this.post = post;
	}
	
	@Override
	public String toString() {
		return userName + "/ " + post;
	}
}
