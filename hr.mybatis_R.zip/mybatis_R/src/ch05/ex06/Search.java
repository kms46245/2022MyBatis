package ch05.ex06;

import java.util.List;

public class Search {
	@SuppressWarnings("unused")
	private int[] userIds;
	@SuppressWarnings("unused")
	private List<String> userNames;
	
	public Search(int[] userIds, List<String> userNames) {
		this.userIds = userIds;
		this.userNames = userNames;
	}
}
