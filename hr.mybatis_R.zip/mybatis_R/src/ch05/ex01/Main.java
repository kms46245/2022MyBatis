package ch05.ex01;

import ch05.domain.Search;
import ch05.domain.User;
import config.Configuration;

public class Main {
	public static void main(String[] args) {
		Map mapper = Configuration.getMapper(Map.class);
		
		User user = mapper.selectUser(new Search("lucider", null));
		User user2 = mapper.selectUser(new Search("coa", null));
		
		System.out.println(user2);
		System.out.println(user);
	}
}
