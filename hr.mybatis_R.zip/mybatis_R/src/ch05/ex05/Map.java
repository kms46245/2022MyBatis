package ch05.ex05;

import ch05.domain.User;

public interface Map {
	User selectUser(String userName);
}
