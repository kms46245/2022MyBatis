package ch05.ex07;

import java.util.Arrays;
import java.util.List;

import ch05.domain.User;
import config.Configuration;

public class Main {
	public static void main(String[] args) {
		Map mapper = Configuration.getMapper(Map.class);
		
		//���� - �ʿ���� null���� ������.
		List<User> users = mapper.selectUsers(new int[] {11, 13, 14});
		List<User> users2 = mapper.selectUsers2(Arrays.asList("coa", "lucider"));
		users.forEach(System.out::println);
		users2.forEach(System.out::println);		
	}
}
