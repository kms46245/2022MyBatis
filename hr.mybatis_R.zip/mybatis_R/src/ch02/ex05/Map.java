package ch02.ex05;

public interface Map {
	int deleteUser(int userId);
}
