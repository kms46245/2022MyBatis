package ch02.ex04;

import ch02.domain.User;

public interface Map {
	int updateUser(User user);
}
