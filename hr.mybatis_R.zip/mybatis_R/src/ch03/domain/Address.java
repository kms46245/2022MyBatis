package ch03.domain;

public class Address {
	private String address;
	
	@Override
	public String toString() {
		return address;
	}
}
