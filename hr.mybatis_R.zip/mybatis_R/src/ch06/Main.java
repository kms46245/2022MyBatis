package ch06;

import ch06.dao.FriendsDao;
import ch06.dao.FriendsDaoImpl;
import ch06.presentation.FriendsIo;
import ch06.service.FriendsService;
import ch06.service.FriendsServiceImpl;

public class Main {
	public static void main(String[] args) {
		FriendsDao friendsDao = new FriendsDaoImpl();
		FriendsService friendsService = new FriendsServiceImpl(friendsDao);
		FriendsIo friendsIo = new FriendsIo(friendsService);
		
		friendsIo.play();
	}
}
