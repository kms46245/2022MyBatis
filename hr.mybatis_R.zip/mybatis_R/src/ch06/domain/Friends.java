package ch06.domain;

import java.time.LocalDate;

public class Friends {
	private int userId;
	private String userName;
	private LocalDate regDate;
	
	@Override
	public String toString() {
		return String.format("%d %s %s", userId, userName, regDate);
	}
}
