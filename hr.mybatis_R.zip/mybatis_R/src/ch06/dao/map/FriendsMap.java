package ch06.dao.map;

import java.util.List;

import ch06.domain.Friends;

public interface FriendsMap {
	List<Friends> selectFriends();
}
