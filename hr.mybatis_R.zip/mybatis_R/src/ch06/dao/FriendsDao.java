package ch06.dao;

import java.util.List;

import ch06.domain.Friends;

public interface FriendsDao {
	List<Friends> selectFriends();
}
