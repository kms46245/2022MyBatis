package ch06.dao;

import java.util.List;

import ch06.dao.map.FriendsMap;
import ch06.domain.Friends;
import config.Configuration;

public class FriendsDaoImpl implements FriendsDao{
	private FriendsMap friendsMap;
	
	public FriendsDaoImpl() {
		this.friendsMap = Configuration.getMapper(FriendsMap.class);
	}
	
	@Override
	public List<Friends>selectFriends(){
		return friendsMap.selectFriends();
	}
}
