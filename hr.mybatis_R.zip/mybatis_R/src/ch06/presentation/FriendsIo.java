package ch06.presentation;

import ch06.service.FriendsService;

public class FriendsIo {
	private FriendsService friendsService;
	
	public FriendsIo(FriendsService friendsService) {
		this.friendsService = friendsService;
	}
	
	public void play() {
		friendsService.getFriends().forEach(System.out::println);
	}
}
