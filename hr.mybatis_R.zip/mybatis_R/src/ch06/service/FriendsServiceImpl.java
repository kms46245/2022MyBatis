package ch06.service;

import java.util.List;

import ch06.dao.FriendsDao;
import ch06.domain.Friends;

public class FriendsServiceImpl implements FriendsService{
	private FriendsDao friendsDao;
	
	public FriendsServiceImpl(FriendsDao friendsDao) {
		this.friendsDao = friendsDao;
	}
	
	@Override
	public List<Friends> getFriends(){
		return friendsDao.selectFriends();
	}
}
