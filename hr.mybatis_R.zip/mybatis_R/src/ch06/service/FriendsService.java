package ch06.service;

import java.util.List;

import ch06.domain.Friends;

public interface FriendsService {
	List<Friends> getFriends();
}
